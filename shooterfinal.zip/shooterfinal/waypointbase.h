#ifndef _WAYPOINT__
#define _WAYPOINT__



#endif
