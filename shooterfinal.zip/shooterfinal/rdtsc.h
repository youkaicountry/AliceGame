
#ifndef RDTSC_H
#define RDTSC_H

extern "C" { void GetTimestamp(void *t); }

#endif
