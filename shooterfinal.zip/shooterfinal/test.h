class test : public Enemy
{
}
